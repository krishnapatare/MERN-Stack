// routes/transactionRoutes.js
const express = require('express');
const {
  initializeDatabase,
  getTransactions,
  getStatistics,
  getBarChartData,
} = require('../controllers/transactionController');

const router = express.Router();

router.get('/initialize', initializeDatabase);
router.get('/transactions', getTransactions);
router.get('/statistics', getStatistics);
router.get('/bar-chart', getBarChartData);

module.exports = router;
