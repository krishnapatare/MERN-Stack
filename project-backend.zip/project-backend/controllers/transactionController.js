// controllers/transactionController.js
const axios = require('axios');
const Transaction = require('../models/transactionModel');

// Fetch and initialize database
const initializeDatabase = async (req, res) => {
  try {
    const response = await axios.get('https://s3.amazonaws.com/roxiler.com/product_transaction.json');
    await Transaction.deleteMany();  // Clear existing data
    await Transaction.insertMany(response.data);
    res.status(200).json({ message: 'Database initialized successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get paginated transactions with search
const getTransactions = async (req, res) => {
  const { page = 1, perPage = 10, search = '', month } = req.query;
  const skip = (page - 1) * perPage;

  try {
    const query = {
      dateOfSale: { $regex: `-${month.padStart(2, '0')}-` },
      $or: [
        { title: new RegExp(search, 'i') },
        { description: new RegExp(search, 'i') },
        { price: { $regex: search } },
      ],
    };

    const transactions = await Transaction.find(query).skip(skip).limit(Number(perPage));
    res.json(transactions);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get statistics
const getStatistics = async (req, res) => {
  const { month } = req.query;
  const monthPattern = `-${month.padStart(2, '0')}-`;

  try {
    const totalSales = await Transaction.aggregate([
      { $match: { dateOfSale: { $regex: monthPattern }, sold: true } },
      { $group: { _id: null, totalAmount: { $sum: '$price' }, totalSoldItems: { $sum: 1 } } },
    ]);

    const notSoldItems = await Transaction.countDocuments({ dateOfSale: { $regex: monthPattern }, sold: false });

    res.json({
      totalSales: totalSales[0]?.totalAmount || 0,
      soldItems: totalSales[0]?.totalSoldItems || 0,
      notSoldItems,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Bar chart data
const getBarChartData = async (req, res) => {
  const { month } = req.query;
  const monthPattern = `-${month.padStart(2, '0')}-`;

  try {
    const priceRanges = [
      { range: '0-100', min: 0, max: 100 },
      { range: '101-200', min: 101, max: 200 },
      { range: '201-300', min: 201, max: 300 },
      { range: '301-400', min: 301, max: 400 },
      { range: '401-500', min: 401, max: 500 },
      { range: '501-600', min: 501, max: 600 },
      { range: '601-700', min: 601, max: 700 },
      { range: '701-800', min: 701, max: 800 },
      { range: '801-900', min: 801, max: 900 },
      { range: '901-above', min: 901 },
    ];

    const result = await Promise.all(priceRanges.map(async ({ range, min, max }) => {
      const count = await Transaction.countDocuments({
        dateOfSale: { $regex: monthPattern },
        price: { $gte: min, ...(max ? { $lte: max } : {}) },
      });
      return { range, count };
    }));

    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
